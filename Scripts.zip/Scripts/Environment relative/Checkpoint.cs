﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Checkpoint : MonoBehaviour
{

    public Vector3 respawnPoint = Vector3.zero;
    private CheckpointManager player;

    private void Start()
    {

        player = GameObject.FindGameObjectWithTag("Player").GetComponent<CheckpointManager>();

    }

    private void OnDrawGizmosSelected()
    {

        Gizmos.color = Color.red;
        Gizmos.DrawSphere(respawnPoint + transform.position, 0.2f);

    }

    private void OnTriggerEnter2D(Collider2D collision)
    {

        if (collision.gameObject.CompareTag("Player"))
        {

            player.setCheckpoint(this);

        }

    }

}
