﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundScript : MonoBehaviour
{

    private AudioSource aud;

    public void setSound(AudioClip aud_)
    {

        aud = gameObject.GetComponent<AudioSource>();
        aud.clip = aud_;

    }

    public void playSound()
    {

        aud.Play();
        Destroy(gameObject, 10);

    }

}
