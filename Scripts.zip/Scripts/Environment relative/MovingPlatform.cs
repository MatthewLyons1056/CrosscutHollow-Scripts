﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class node // class used to defined the nodes the platform will travel between
{

    public Vector2 position;
    public float movementTime;

}

[ExecuteAlways]
public class MovingPlatform : MonoBehaviour
{

    public List<node> positions = new List<node>(); // variable node list the platform will travel between
    public Vector2[] top = new Vector2[2]; // defines the top of the platform to make players and object move with the platform
    public float delay = 0f; // the amount of time before the platform starts looping (used to offset platforms with similar movements)

    private Rigidbody2D rb;
    private int pos = 0;
    private Vector3 to = new Vector3();
    private Vector3 from = new Vector3();
    private float percentage;
    private float startTime;
    private float endTime;
    private Vector3 percPos;
    private Vector2 offset;
    private RaycastHit2D[] carrying = new RaycastHit2D[0];
    private bool jumping = false;
    private Vector2 offset2;

    void Start()
    {

        if (Application.isPlaying)
        {

            offset2 = transform.position;
            foreach (node n in positions)
            {

                n.position += offset2;

            }
            rb = gameObject.GetComponent<Rigidbody2D>();
            transform.position = positions[0].position;
            to = transform.position;
            StartCoroutine(moveToNextNode());

        }

    }

    private void OnDrawGizmosSelected() // draws the path the platform will take as well as the nodes
    {

        if (!Application.isPlaying)
        {

            offset = (Vector2)transform.position;
        
        }
        Vector2 tmp = Vector2.zero;
        int curPos = 0;
        foreach (node curNode in positions)
        {

            Gizmos.color = Color.Lerp(Color.red, Color.green, curPos / positions.Count - 0.99f);
            Gizmos.DrawSphere(offset + curNode.position, 0.4f);
            if (tmp != Vector2.zero)
            {

                Gizmos.DrawLine(offset + tmp, offset + curNode.position);

            }
            else
            {

                Gizmos.DrawLine(offset + positions[0].position, offset + positions[positions.Count - 1].position);

            }
            tmp = curNode.position;
            curPos++;

        }
        Gizmos.color = Color.blue;
        Gizmos.DrawLine((Vector2)transform.position + top[0], (Vector2)transform.position + top[1]);

    }

    private IEnumerator moveToNextNode() // sets the target to the next node and moves the platform (returns to node 0 when the end is reached)
    {

        yield return new WaitForSeconds(delay);
        GameObject tmp = null;
        while (true)
        {

            startTime = Time.time;
            endTime = Time.time + positions[pos].movementTime;
            from = offset + positions[pos].position;
            if (pos >= positions.Count - 1)
            {

                pos = 0;

            }
            else
            {

                pos++;

            }
            to = offset + positions[pos].position;
            if (startTime != endTime)
            {

                while (Time.time < endTime)
                {

                    percentage = bezierCurve((Time.time - startTime) / (endTime - startTime));
                    percPos = Vector3.Lerp(from, to, percentage);
                    /*carrying = Physics2D.LinecastAll((Vector2)transform.position + top[0], (Vector2)transform.position + top[1]);
                    if (carrying.Length > 0)
                    {

                        foreach (RaycastHit2D obj in carrying)
                        {

                            tmp = obj.transform.gameObject;
                            if (tmp.CompareTag("Player") && Input.GetAxisRaw("Horizontal") == 0 && Input.GetAxisRaw("Vertical") == 0 && !Input.GetButton("Jump"))
                            {

                                tmp.GetComponent<Rigidbody2D>().MovePosition(percPos + tmp.transform.position - transform.position);

                            }

                        }

                    }*/
                    rb.MovePosition(percPos);
                    yield return new WaitForFixedUpdate();

                }

            }
            else
            {

                transform.position = to;
                yield return new WaitForFixedUpdate();

            }

        }
        
    }

    private float bezierCurve(float input) // returns a smoothed movement path for the platform's movement
    {

        return -(Mathf.Cos(Mathf.PI * input) - 1) / 2;

    }

}
