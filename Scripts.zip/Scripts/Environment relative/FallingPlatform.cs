﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FallingPlatform : MonoBehaviour
{

    public float fallTimer = 1.0f; // amount of time from the player stepping on a tile to it falling down
    public float respawnTimer = 5.0f; // the amount of time it takes for the platform to respawn (-1 for no respawn)

    private bool falling = false;
    private Animator anim;

    private void Start()
    {

        anim = transform.GetChild(0).GetComponent<Animator>();

    }

    private IEnumerator touched() // function called when the platform is touched
    {

        falling = true;
        anim.SetInteger("state", 1);
        yield return new WaitForSeconds(fallTimer - 0.2f);
        GetComponent<Collider2D>().enabled = false;
        anim.SetInteger("state", 2);
        if (respawnTimer >= 0)
        {

            yield return new WaitForSeconds(respawnTimer);
            GetComponent<Collider2D>().enabled = true;
            anim.SetInteger("state", 0);
            falling = false;

        }
        else if (respawnTimer <= -1)
        {

            Destroy(gameObject);
            yield return null;

        }

    }

    private void OnCollisionEnter2D(Collision2D collision) // calls the touched() coroutine when player makes contact
    {
        
        if (!falling && collision.gameObject.CompareTag("Player"))
        {

            StartCoroutine(touched());

        }

    }

}
