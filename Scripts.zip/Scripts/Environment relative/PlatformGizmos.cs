﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// DEPRECIATED SCRIPT

[ExecuteInEditMode]
public class PlatformGizmos : MonoBehaviour
{
    void Start()
    {
        
    }

    private void OnDrawGizmosSelected()
    {

        Vector2 tmp = Vector2.zero;
        for (int a = transform.childCount - 1; a >= 1; a--)
        {

            Gizmos.color = Color.Lerp(Color.red, Color.green, a / (transform.childCount - 0.999f));
            Gizmos.DrawSphere(transform.GetChild(a).position, 0.4f);
            if (tmp != Vector2.zero)
            {

                Gizmos.DrawLine(tmp, transform.GetChild(a).position);

            }
            else
            {

                Gizmos.DrawLine(transform.GetChild(1).position, transform.GetChild(transform.childCount - 1).position);

            }
            tmp = transform.GetChild(a).position;



        }

    }

}
