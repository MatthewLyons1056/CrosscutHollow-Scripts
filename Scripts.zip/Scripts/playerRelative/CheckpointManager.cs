﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CheckpointManager : MonoBehaviour
{

    public Checkpoint currentCheckpoint;

    public void setCheckpoint(Checkpoint checkpoint_)
    {

        currentCheckpoint = checkpoint_;

    }

    public Checkpoint getCheckpoint()
    {

        return currentCheckpoint;

    }

}
