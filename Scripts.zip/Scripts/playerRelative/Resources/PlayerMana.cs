﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMana : MonoBehaviour
{
    public int maxMana = 100;
    public int currentMana;

    public ResourceBar rBar;

    // Start is called before the first frame update
    void Start()
    {
        currentMana = maxMana;
        rBar.SetMaxValue(maxMana);
    }

    // Update is called once per frame
    void Update()
    {

        /*if (Input.GetKeyDown(KeyCode.V))
        {
            rBar.GainMana(20);   
        }*/

        if (currentMana > 5)
        {
            currentMana = 5;
        }

    }

    
}
