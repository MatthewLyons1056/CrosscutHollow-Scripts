﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerTakeDamage : MonoBehaviour
{
    public ResourceBar rBar;

    //public RigidBody2D RB;

    void OnCollisionEnter2D(Collision2D col)
    {
        if (col.gameObject.CompareTag("Enemy"))
        {
            //Debug.Log("Enemy Hit Player");

            rBar.TakeDamage(1);
        }


    }

    public void applyDamge(int damage_)
    {

        rBar.TakeDamage(damage_);

    }

}
