﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerHealth : MonoBehaviour
{
    public int maxHealth = 5;
    public int currentHealth;

    public ResourceBar resourceBar;

    public GameOver gameOver;
    public GameObject lowHP;

    // Start is called before the first frame update
    void Start()
    {
        currentHealth = maxHealth;
        resourceBar.SetMaxValue(maxHealth);
    }

    // Update is called once per frame
    void Update()
    {
        
       

        if (currentHealth < 1)
        {
            gameOver.GameOverPanel();
            
        }
        if (currentHealth > 10)
        {
            currentHealth = 10;
        }
        if (1.0f * currentHealth / maxHealth < 0.5f)
        {

            lowHP.SetActive(true);

        }
        else
        {

            lowHP.SetActive(false);

        }

    }
    

   
}
