﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LadderClimb : MonoBehaviour
{

    public float stickiness = 20.0f; // how hard the players will be pulled towards the center of the ladder
    private float climbSpeed = 4.0f; // the speed at which the player climbs up or down
    private float ends = 0.5f; // how close to the top the player can climb up a ladder

    private float normGravity;
    private Rigidbody2D rb;
    public List<GameObject> ladders; // all ladders currently colliding with the player
    private GameObject closestLadder;
    private float[] ladderBounds = new float[2];
    public bool isClimbing = false;
    private float jumpForce;
    private CharacterController2D charCon;
    public Animator anim;

    void Start()
    {

        anim = gameObject.GetComponent<Animator>();
        charCon = gameObject.GetComponent<CharacterController2D>();
        jumpForce = charCon.getJumpForce();
        rb = gameObject.GetComponent<Rigidbody2D>();
        normGravity = rb.gravityScale;

    }

    private void OnTriggerEnter2D(Collider2D other) // adds new ladders to the list when colliding
    {

        if (other.gameObject.CompareTag("Ladder") && !ladders.Contains(other.gameObject))
        {

            ladders.Add(other.gameObject);

        }
    
    }

    private void OnTriggerExit2D(Collider2D other) // removes old ladders from the list when collision ends
    {

        if (other.gameObject.CompareTag("Ladder") && ladders.Contains(other.gameObject))
        {

            ladders.Remove(other.gameObject);
            

        }

    }

    private GameObject getClosestLadder() // returns the closest ladder to the player or null (also sets ladder top and bottom)
    {

        if (ladders.Count > 0)
        {

            GameObject tmp = null;
            float dist = 999;
            foreach (GameObject ladder in ladders)
            {

                if (Mathf.Abs(transform.position.x - ladder.transform.position.x) < dist)
                {

                    dist = Mathf.Abs(transform.position.x - ladder.transform.position.x);
                    tmp = ladder;

                }

            }

            ladderBounds[0] = tmp.transform.position.y - (tmp.GetComponent<BoxCollider2D>().bounds.size.y / 2);
            ladderBounds[1] = tmp.transform.position.y + (tmp.GetComponent<BoxCollider2D>().bounds.size.y / 2);
            return tmp;

        }
        else
        {

            return null;

        }

    }

    public void setClimbing(bool climb) // toggles gravity when climbing the ladder as well as setting the isClimbing bool
    {

       // Debug.Log("setting ladder climbing to status: " + climb);
        
        

        isClimbing = climb;
        
        if (climb)
        {

            rb.gravityScale = 0;

        }
        else
        {

            rb.gravityScale = normGravity;

        }   

    }

    private void processClimb() // handles the climbing logic of the player
    {

        if (isClimbing)
        {

            if (Input.GetButton("Jump") || Mathf.Abs(transform.position.x - closestLadder.transform.position.x) >= (closestLadder.GetComponent<BoxCollider2D>().bounds.size.x / 2) || transform.position.y <= ladderBounds[0] || transform.position.y >= ladderBounds[1])
            {

                setClimbing(false);
                anim.SetBool("IsClimbing", false);
                Debug.Log("Player is not clibming");

            }
            else
            {

                float move = 0;
                if (Input.GetAxisRaw("Vertical") > 0 && transform.position.y < ladderBounds[1] - ends)
                {

                    move += 1;

                }
                else if (Input.GetAxisRaw("Vertical") < 0)
                {

                    move -= 1;

                }
                rb.velocity = new Vector2(rb.velocity.x, move * climbSpeed);
                rb.AddForce(new Vector2(closestLadder.transform.position.x - transform.position.x, 0) * stickiness);

            }
            if (Input.GetButton("Jump")) {

                rb.velocity = new Vector2(rb.velocity.x, 0);
                rb.AddForce(new Vector2(0, jumpForce));

            }

        }
        else
        {

            if (Input.GetAxisRaw("Vertical") != 0 && !Input.GetButton("Jump"))
            {

                closestLadder = getClosestLadder();
                if (closestLadder != null)
                {
                
                    if (Mathf.Abs(transform.position.x - closestLadder.transform.position.x) <= (closestLadder.transform.localScale.x / 2))
                    {

                        setClimbing(true);
                        anim.SetBool("IsClimbing", true);
                        Debug.Log("Player is clibming");

                    }
                
                }

            }

        }

    }

    void Update()
    {

        processClimb();

    }

}