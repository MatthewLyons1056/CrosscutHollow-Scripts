﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dash : MonoBehaviour
{

    public float DashGrace = 0.1f; // the maximum amount of time between taps to initiate a dash
    public float DashDelay = 1.0f; // the cooldown between consecutive dashes
    public float DashForce = 2000f; // the force applied to the player when the dash starts
    public float DashTime = 0.1f; // the period of time in which input will be ignored and gravity will be negated

    private bool canDash = true;
    private float gravity;
    private Rigidbody2D rb;
    private float ldTimer = -1f;
    private float rdTimer = -1f;
    private PlayerMovement pm;
    private CharacterController2D charCon;

    void Start()
    {

        charCon = gameObject.GetComponent<CharacterController2D>();
        pm = gameObject.GetComponent<PlayerMovement>();
        rb = gameObject.GetComponent<Rigidbody2D>();
        gravity = rb.gravityScale;

    }
    
    private IEnumerator initiateDash(bool dirRight) // called when the criteria are met to perform a dash
    {

        canDash = false;
        rb.gravityScale = 0;
        pm.setIgnoreInput(true);
        if (dirRight)
        {

            rb.velocity = new Vector2(DashForce, 0);

        }
        else
        {

            rb.velocity = new Vector2(-DashForce, 0);

        }
        yield return new WaitForSeconds(DashTime);
        rb.gravityScale = gravity;
        pm.setIgnoreInput(false);
        yield return new WaitForSeconds(DashDelay - DashTime);
        canDash = true;

    }
    

    void Update()
    {
        
        if (canDash && !charCon.getGrounded() && Input.GetButtonDown("Horizontal"))
        {

            if (Input.GetAxisRaw("Horizontal") > 0)
            {

                if (Time.time > rdTimer)
                {

                    rdTimer = Time.time + DashGrace;

                }
                else
                {

                    StartCoroutine(initiateDash(true));

                }

            }
            else
            {

                if (Time.time > ldTimer)
                {

                    ldTimer = Time.time + DashGrace;

                }
                else
                {

                    StartCoroutine(initiateDash(false));

                }

            }

        }

    }

}
