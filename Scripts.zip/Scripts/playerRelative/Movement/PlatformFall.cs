﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlatformFall : MonoBehaviour
{

    private bool ignoring = false;

    void Update()
    {

        if (Input.GetAxisRaw("Vertical") < 0 && !ignoring)
        {

            ignoring = true;
            foreach (GameObject g in GameObject.FindGameObjectsWithTag("Platform"))
            {

                Physics2D.IgnoreCollision(g.GetComponent<Collider2D>(), GetComponents<Collider2D>()[0], true);
                Physics2D.IgnoreCollision(g.GetComponent<Collider2D>(), GetComponents<Collider2D>()[1], true);

            }

        }
        else if (Input.GetAxisRaw("Vertical") >= 0 && ignoring)
        {

            ignoring = false;
            foreach (GameObject g in GameObject.FindGameObjectsWithTag("Platform"))
            {

                Physics2D.IgnoreCollision(g.GetComponent<Collider2D>(), GetComponents<Collider2D>()[0], false);
                Physics2D.IgnoreCollision(g.GetComponent<Collider2D>(), GetComponents<Collider2D>()[1], false);

            }

        }

    }

}
