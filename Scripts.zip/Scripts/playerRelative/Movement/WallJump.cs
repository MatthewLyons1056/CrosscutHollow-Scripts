﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallJump : MonoBehaviour
{

    public float jumpforce = 2.0f;
    private float verticalVelocity = 1500.0f;
    private float horizontalVelocity = 1200.0f;


    private Transform col;
    private Rigidbody2D rb;
    private CharacterController2D charCon;

    void Start()
    {
        verticalVelocity *= jumpforce;
        horizontalVelocity *= jumpforce;
        rb = gameObject.GetComponent<Rigidbody2D>();
        charCon = gameObject.GetComponent<CharacterController2D>();
        col = gameObject.transform.GetChild(7);

    }

    // Update is called once per frame
    void Update()
    {
        
        if (Input.GetButtonDown("Jump") && !charCon.getGrounded())
        {

            Collider2D[] collisions = Physics2D.OverlapCircleAll(col.position, 0.1f);
            bool tmp = false;
            foreach (Collider2D collision in collisions)
            {

                if (collision.gameObject.CompareTag("Sticky"))
                {

                    tmp = true;

                }

            }
            if (tmp)
            {

                Debug.Log("jump");
                rb.velocity = new Vector2(0, 0);
                if (charCon.getFacingRight())
                {

                    rb.AddForce(new Vector2(-horizontalVelocity, verticalVelocity));

                }
                else
                {

                    rb.AddForce(new Vector2(horizontalVelocity, verticalVelocity));

                }

            }

        }

    }

}
