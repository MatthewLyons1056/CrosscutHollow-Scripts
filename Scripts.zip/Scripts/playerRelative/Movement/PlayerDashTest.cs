﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerDashTest : MonoBehaviour
{
    public Rigidbody2D rb;
    public float thrust;
    private int direction;

    //Add bools that create a condition for directions

    private bool directionL = false;
    private bool directionR = false;
    private bool directionU = false;
    private bool directionD = false;

    //

    private IEnumerator coroutine;


    void Start()
    {
        // - After 0 seconds, prints "Starting 0.0 seconds"
        // - After 0 seconds, prints "Coroutine started"
        // - After 2 seconds, prints "Coroutine ended: 2.0 seconds"
        //print("Starting " + Time.time + " seconds");

        // Start function WaitAndPrint as a coroutine.

        coroutine = WaitAndPrint(2.0f);
        //StartCoroutine(coroutine);

        //print("Coroutine started");

    }

    void Update()
    {
        
        DirectionLeft();
        DirectionRight();
        DirectionUp();
        DirectionDown();


        //Turn this on if u want the dash to work...
        /*if (Input.GetKeyDown(KeyCode.K))
        {
            Debug.Log("up is " + directionU);
            Debug.Log(" left is " + directionL);
            DirectionCheck();
        }*/
        
        //Testing gravity change

        if (Input.GetKeyDown(KeyCode.G))
        {
            rb.gravityScale = 0;
        }
    }

    private IEnumerator WaitAndPrint(float waitTime)
    {
        yield return new WaitForSeconds(waitTime);
        print("Coroutine ended: " + Time.time + " seconds");
    }

    void DirectionCheck()
    {
        //For this dash to properly work, need to remove gravity during dash... Add an IENumerator to do so
        if (directionD == true)
        {
            rb.velocity = Vector2.down * thrust; // go down
        }
        if (directionU == true)
        {
            rb.velocity = Vector2.up * 25; // go up
        }
        if (directionL == true)
        {
            rb.velocity = (Vector2.left * thrust); // go left
        }
        if (directionR == true)
        {
            rb.velocity = Vector2.right * thrust; // go right
        }
       
        

        // For Diagonal Dashing

        /*if (directionL == true && directionU == true)
        {
            rb.velocity = (Vector2.left * thrust) + (Vector2.up * 25); // go Left and Up
        }
        if (directionR == true && directionU == true)
        {
            rb.velocity = (Vector2.right * thrust) + (Vector2.up * 25); // go Right and Up
        }
        if (directionL == true && directionD == true)
        {
            rb.velocity = (Vector2.left * thrust) + (Vector2.down * 25); // go left and Down
        }
        if (directionR == true && directionD == true)
        {
            rb.velocity = (Vector2.right * thrust) + (Vector2.down * 25); // go Right and Down
        }*/
        



        //Create 20 if statements that control each possible direciton... Example being 

        //The bug is... The rb.velocity is being overwritten by the last If Statement that is true
        //The solution is to 

        //Remove Gravity during dash

        //Createe IENumerator to remove gravity during dash, then increase gravity over .3f
    }
    void DirectionLeft()
    {
        if (Input.GetKey(KeyCode.A))
        {
            directionL = true;
        }
        else
        {
            directionL = false;
        }
    }
    void DirectionRight()
    {
        if (Input.GetKey(KeyCode.D))
        {
            directionR = true;
        }
        else
        {
            directionR = false;
        }
    }
    void DirectionUp()
    {
        if (Input.GetKey(KeyCode.W))
        {
            directionU = true;
        }
        else
        {
            directionU = false;
        }
    }
    void DirectionDown()
    {
        if (Input.GetKey(KeyCode.S))
        {
            directionD = true;
        }
        else
        {
            directionD = false;
        }
    }
    void Direction()
    {
        if (Input.GetKeyDown(KeyCode.A))
        {
            direction = 1;
            Debug.Log("D = 1");

        }
        else if (Input.GetKeyDown(KeyCode.D))
        {
            direction = 2;
            Debug.Log("D = 2");
        }
        else if (Input.GetKeyDown(KeyCode.Space))
        {
            direction = 3;
            Debug.Log("D = 3");
        }
        else if (Input.GetKeyDown(KeyCode.S))
        {
            direction = 4;
            Debug.Log("D = 4");
        }
    }
}
