﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerDash : MonoBehaviour
{
    public Rigidbody2D rb;
    public float thrust;
    private int direction;

    void Start()
    {


    }

    void Update()
    {
        Direction();

        if (Input.GetKeyDown(KeyCode.K))
        {

            DirectionCheck();
        }
    }

    void DirectionCheck()
    {
        if (direction == 1)
        {
            rb.velocity = Vector2.left * thrust;
        }
        else if (direction == 2)
        {
            rb.velocity = Vector2.right * thrust;
        }
        else if (direction == 3)
        {
            rb.velocity = Vector2.up * 10;
        }
        else if (direction == 4)
        {
            rb.velocity = Vector2.down * thrust;
        }
    }

    void Direction()
    {
        if (Input.GetKeyDown(KeyCode.A))
        {
            direction = 1;
            Debug.Log("D = 1");

        }
        else if (Input.GetKeyDown(KeyCode.D))
        {
            direction = 2;
            Debug.Log("D = 2");
        }
        else if (Input.GetKeyDown(KeyCode.Space))
        {
            direction = 3;
            Debug.Log("D = 3");
        }
        else if (Input.GetKeyDown(KeyCode.S))
        {
            direction = 4;
            Debug.Log("D = 4");
        }
    }
}
