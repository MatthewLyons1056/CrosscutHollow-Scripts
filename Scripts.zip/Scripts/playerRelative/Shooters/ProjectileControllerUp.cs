﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProjectileControllerUp : MonoBehaviour
{
    public float Speed;
    public int damage = 20;
    //public GameObject impactEffect;
    public Rigidbody2D rb;

    //public ProjectileShooter PShooter;
    //Audio goes here

    public AudioSource fireBallCastSound;
    
    //public AudioSource fireballCollisionSound;

    //public AudioClip clip;

    void Start()
    {

        rb.velocity = transform.right * Speed;
        rb.rotation = -270f;
        fireBallCastSound.Play();
    }

    void OnTriggerEnter2D(Collider2D hitInfo)
    {
        //needs to delete fireball when colliding with other

        Enemy enemy = hitInfo.GetComponent<Enemy>();
        if (enemy != null)
        {
            //put new location here, play fireball sound at location
            enemy.TakeDamage(damage);
            DestroyFBall();
        }
        if (hitInfo.gameObject.CompareTag("Wall"))
        {
            DestroyFBall();
        }
        





        //Make a impact effect here
        //Instantiate(impactEffect, transform.position, transform.rotation);

        //Play sound

        //AudioSource.PlayClipAtPoint(clip, new Vector3(0,0,0));


        //this will create bugs lol
        
        void DestroyFBall()
        {
            Destroy(gameObject);
            Destroy(transform.parent.gameObject);
        }


        
    }
}
