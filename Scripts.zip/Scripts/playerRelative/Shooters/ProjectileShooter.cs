﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProjectileShooter : MonoBehaviour
{
    //Reference series of projectiles
    public GameObject projectile;
    public GameObject projectileUp;
    public GameObject projectileDown;



    public Transform ShotLocation;
    public Transform ShotLocationOriginal;
    public Transform ShotLocationUp;
    public Transform ShotLocationDown;

    //Custom Bools to refer logic
    
   

    public ProjectileController PController;

    //ManaPerlostCast
    public int fireBallManaCost = 20; 
    
    //Reference to mana script

    public PlayerMana pMana;
    public ResourceBar rBar;

    // Update is called once per frame
    
    
    void Update()
    {

        

        //------------------------------------
        if (Input.GetButtonDown("Fire1") && pMana.currentMana >= fireBallManaCost)
        {
            if (Input.GetKey(KeyCode.W))
            {
                
                
                ShotLocation.position = ShotLocationUp.position;
                ShootUp();
            }
            else if (Input.GetKey(KeyCode.S))
            {
                
                ShotLocation.position = ShotLocationDown.position;
                ShootDown();
            }
            
            else
            {
                
                ShootOG();
                
            }
            
            rBar.UseMana(fireBallManaCost);
        }

       

        
        //else print text "out of mana" 
        //Audio Clip that plays a "out of mana" sound 

        

        void Shoot()
        {
            
            Instantiate(projectile, ShotLocation.position, ShotLocation.rotation);
        }
        void ShootUp()
        {

            Instantiate(projectileUp, ShotLocation.position, ShotLocation.rotation);
        }
        void ShootDown()
        {

            Instantiate(projectileDown, ShotLocation.position, ShotLocation.rotation);
        }

        void ShootOG()
        {

            Instantiate(projectile, ShotLocationOriginal.position, ShotLocationOriginal.rotation);
        }
    }
}
