﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameOver : MonoBehaviour
{

    public bool pGameOver = false;

    public GameObject panel;
    public ResourceBar health;
    public ResourceBar mana;

    void Start()
    {
        Time.timeScale = 1f;
        pGameOver = false;
        panel.gameObject.SetActive(false);
    }

    public void GameOverPanel()
    {

        panel.gameObject.SetActive(true);
        Time.timeScale = 0f;

    }
    public void HidePanel()
    {

        panel.gameObject.SetActive(false);
        Time.timeScale = 1f;
        health.heal();
        mana.rejuvinate();

    }



}
