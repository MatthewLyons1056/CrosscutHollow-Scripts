﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// DEPRECIATED SCRIPT

public class MeleeAttackOld : MonoBehaviour
{

    private float[] angles = new float[3] { 45, 0, -45 }; // angle of the up, normal, and down attacks
    private float[] dists = new float[3] { 1, 1, 1 }; // distance from origin of the up, normal, and down attacks
    private float attackDelay = 1.0f; // cooldown between attacks

    private float nextAttack;
    private Vector3 attackOrigin;
    float toRads = (Mathf.PI / 180);

    void Start()
    {

        nextAttack = Time.time;
        attackOrigin = transform.GetChild(5).position - transform.position;

    }

    private void OnDrawGizmos()
    {

        Gizmos.color = Color.red;
        Gizmos.DrawLine(attackOrigin + transform.position, transform.position + new Vector3(dists[0] * Mathf.Cos(toRads * angles[0]), dists[0] * Mathf.Sin(toRads * angles[0])));
        Gizmos.color = Color.green;
        Gizmos.DrawLine(attackOrigin + transform.position, transform.position + new Vector3(dists[1] * Mathf.Cos(toRads * angles[1]), dists[1] * Mathf.Sin(toRads * angles[1])));
        Gizmos.color = Color.blue;
        Gizmos.DrawLine(attackOrigin + transform.position, transform.position + new Vector3(dists[2] * Mathf.Cos(toRads * angles[2]), dists[2] * Mathf.Sin(toRads * angles[2])));

    }

    void Update()
    {
        
        if (Input.GetButtonDown("Fire2") && Time.time >= nextAttack)
        {

            nextAttack = Time.time + attackDelay;
            if (Input.GetAxisRaw("Vertical") > 0)
            {

                
                

            }
            else if (Input.GetAxisRaw("Vertical") < 0)
            {



            }
            else
            {



            }

        }

    }

}
