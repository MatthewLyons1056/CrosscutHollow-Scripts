﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class pickUp : MonoBehaviour
{
    
    public GameObject thing;
    public bool pickedUp;
    public string player;
    public CapsuleCollider2D nonTriggerCollider;
    public AudioClip aud;
    public GameObject sound;

    //reference to key

    public GameObject Key;
    

    private void Start()
    {
        pickedUp = false;
    }

    void OnTriggerEnter2D(Collider2D col)
        {
        //Debug.Log("Running.");
            if (col.CompareTag(player))
            {

                Key.SetActive(true);
                Debug.Log("Activate Key Icon");
                pickedUp = true;
                thing.GetComponent<SpriteRenderer>().enabled = false;
                nonTriggerCollider.enabled = false;
                thing.GetComponent<pickUp>().enabled = false;
                if (aud != null)
                {
            
                    GameObject tmp = Instantiate(sound, transform.position, transform.rotation);
                    tmp.GetComponent<SoundScript>().setSound(aud);
                    tmp.GetComponent<SoundScript>().playSound();
            
                }

            }

        }
}
