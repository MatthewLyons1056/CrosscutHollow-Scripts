﻿ using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class EndGame : MonoBehaviour
{
    public string player;
    public GameObject switchLocation;
    public GameObject message;





    void Update()
    {

    }

    private void OnTriggerEnter2D(Collider2D col)
    {
        if (col.CompareTag(player))
        {
            message.SetActive(true);

            if (Input.GetKeyDown(KeyCode.Q));
            {
                SceneManager.LoadScene(3);
                Debug.Log("Load Scene 3");
            }
        }
    }
    private void OnTriggerExit2D(Collider2D col)
    {
        if (col.CompareTag(player))
        {
            message.SetActive(false);
        }
    }

}
