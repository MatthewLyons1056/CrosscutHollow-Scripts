﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AmmoPickup : MonoBehaviour
{
    public int restoreAmmoByThisMuch;
    public string playerTag;

    public ResourceBar resourceBar;
    public PlayerMana pMana;

    // Start is called before the first frame update
    void Start()
    {

        resourceBar = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerMana>().rBar;
        pMana = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerMana>();

    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.CompareTag(playerTag))
        {
            //player.GetComponent<PlayerHealth>().currentHealth = player.GetComponent<PlayerHealth>().currentHealth + healByThisMuch;
            other.gameObject.GetComponent<PlayerMana>().currentMana = other.gameObject.GetComponent<PlayerMana>().currentMana + restoreAmmoByThisMuch;
            resourceBar.GetComponent<ResourceBar>().SetValue(pMana.currentMana);

            /*if (other.gameObject.GetComponent<PlayerMana>().currentMana > other.gameObject.GetComponent<PlayerMana>().maxMana)
            {
                other.gameObject.GetComponent<PlayerMana>().currentMana = other.gameObject.GetComponent<PlayerMana>().maxMana;
            }*/

            gameObject.GetComponent<AmmoPickup>().enabled = false;
            Destroy(gameObject, 0.0f);
        }
    }
}
