﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BASEPowerUp : MonoBehaviour
{
    private IEnumerator duration;
    public string player;
    public GameObject pickUp;
    public float howLong;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        duration = Lasting(howLong);

        if (collision.CompareTag(player))
        {
            Debug.Log("PowerUp Start");
            StartCoroutine(duration);
        }
    }
    private IEnumerator Lasting(float howLong)
    {
        while (true)
        {
            yield return new WaitForSeconds(howLong);
            Debug.Log("PowerUp End");
            Destroy(pickUp, 0.0f);
        }
    }
}
