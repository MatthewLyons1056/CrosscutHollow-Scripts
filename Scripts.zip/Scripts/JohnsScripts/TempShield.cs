﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TempShield : MonoBehaviour
{
    private IEnumerator duration;
    public string player;
    public GameObject pickUp;
    public float howLong;

    public int shieldValue;
    //public GameObject playerCharacter;
    public int originalHP;

    // Start is called before the first frame update
    void Start()
    {
        originalHP = 10;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnTriggerEnter2D(Collider2D other)
    {
        duration = Lasting(howLong, other);

        if (other.CompareTag(player))
        {
            Debug.Log("PowerUp Start");
            other.gameObject.GetComponent<PlayerHealth>().maxHealth = other.gameObject.GetComponent<PlayerHealth>().maxHealth + shieldValue;
            other.gameObject.GetComponent<PlayerHealth>().currentHealth = other.gameObject.GetComponent<PlayerHealth>().currentHealth + shieldValue;
            other.gameObject.GetComponent<PlayerHealth>().resourceBar.SetValue(other.gameObject.GetComponent<PlayerHealth>().resourceBar.pHealth.currentHealth);
            StartCoroutine(duration);
        }
    }
    private IEnumerator Lasting(float howLong, Collider2D other)
    {
        while (true)
        {
            yield return new WaitForSeconds(howLong);
            Debug.Log("PowerUp End");
            other.gameObject.GetComponent<PlayerHealth>().maxHealth = originalHP;
            if (other.gameObject.GetComponent<PlayerHealth>().currentHealth > other.gameObject.GetComponent<PlayerHealth>().maxHealth)
            {
                other.gameObject.GetComponent<PlayerHealth>().currentHealth = other.gameObject.GetComponent<PlayerHealth>().maxHealth;

            }
            gameObject.GetComponent<TempShield>().enabled = false;
            Destroy(pickUp, 0.0f);
        }
    }
}
