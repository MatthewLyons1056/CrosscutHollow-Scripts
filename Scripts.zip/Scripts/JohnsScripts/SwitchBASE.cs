﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SwitchBASE : MonoBehaviour
{
    public Animator anim;
    public Animator anim2;

    public string player;
    public GameObject switchLocation;
    public GameObject door;
    public GameObject message;
    public KeyCode throwSwitch;
    private bool isOn = false;
    private bool isIn = false;
    

    public bool changeScene;
    public bool isSwitched;
    public string winScene;

    //reference sound
    public AudioSource leverSound;

    // Start is called before the first frame update
    void Start()
    {
      
    }

    // Update is called once per frame
    void Update()
    {
        AnimatorStateInfo stateInfo = anim.GetCurrentAnimatorStateInfo(0);
        AnimatorStateInfo stateInfo2 = anim2.GetCurrentAnimatorStateInfo(0);

        if (changeScene == false)
        {
            if (isOn == false)
            {
                door.SetActive(true);      
            }
            if (isOn == true)
            {
                door.SetActive(false);
            }
        }
        if (changeScene == true)
        {
            if (isOn == false)
            {
                //SceneManager.LoadScene(3);
            }
        }

        if (isIn == true)
        {
            if (Input.GetKeyUp(throwSwitch))
            {//this is where the Animation will be
                       
                Debug.Log("Throw");
                //play sound
                leverSound.Play();
                        
                isOn = !isOn;   
            }
        }

        if (isOn == true)
        {
            anim.SetBool("switchDown", true);
            anim2.SetBool("hatchOpen", true);
        }
        if (isOn == false)
        {
            anim.SetBool("switchDown", false);
            anim2.SetBool("hatchOpen", false);
        }

    }

    private void OnTriggerEnter2D(Collider2D col)
    {
        if (col.CompareTag(player))
        {
            message.SetActive(true);
            isIn = true;
        }
    }
    private void OnTriggerExit2D(Collider2D col)
    {
        if (col.CompareTag(player))
        {
            message.SetActive(false);
            isIn = false;
        }
    }

}
