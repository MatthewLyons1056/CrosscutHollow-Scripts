﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealPickup : MonoBehaviour
{
    public int healByThisMuch;
    public string playerTag;
    //public GameObject player;
    public ResourceBar resourceBar;
    public PlayerHealth pHealth;

    private void Start()
    {

        resourceBar = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerHealth>().resourceBar;
        pHealth = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerHealth>();

    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        //Condition var
        if (other.CompareTag(playerTag))
        {

            //player.GetComponent<PlayerHealth>().currentHealth = player.GetComponent<PlayerHealth>().currentHealth + healByThisMuch;
            other.gameObject.GetComponent<PlayerHealth>().currentHealth = other.gameObject.GetComponent<PlayerHealth>().currentHealth + healByThisMuch;
            resourceBar.GetComponent<ResourceBar>().SetValue(pHealth.currentHealth);
          
            Debug.Log("Health Pickup is true");
            


            gameObject.GetComponent<HealPickup>().enabled = false;
            Destroy(gameObject, 0.0f);

        }
    }
}
