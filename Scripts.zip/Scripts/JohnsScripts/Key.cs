﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Key : MonoBehaviour
{

    public string objectTag;
    public GameObject key;
    public bool pickedUp = false;
    // bring the key to the door and a keypress will "insert" it into the door. If you have one key it'll have some indication that the one key was inserted into the 2 key door.
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag(objectTag))
        {
            pickedUp = true;
            key.SetActive(false);
        }
    }
}
