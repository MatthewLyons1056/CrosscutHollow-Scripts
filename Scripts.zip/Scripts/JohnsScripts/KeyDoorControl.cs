﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KeyDoorControl : MonoBehaviour
{
    public GameObject[] keys;
    public GameObject getMore;
    public GameObject keysFound;
    public bool allKeysPickedUp;
    private bool isItPickedup;
    public GameObject door;
    public string player;
    public KeyCode use;
    // bring the key to the door and a keypress will "insert" it into the door. If you have one key it'll have some indication that the one key was inserted into the 2 key door.

    //reference keys to reset
    public GameObject RedKey;
    public GameObject BlueKey;
    public GameObject YellowKey;


    void Start()
    {
        allKeysPickedUp = false;
        isItPickedup = false;
        getMore.SetActive(false);
        keysFound.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        for (int i=0; i < keys.Length; i++)
        {
            if (keys[i].GetComponent<pickUp>().pickedUp == true)
            {
                isItPickedup = true;
            }
            else
            {
                isItPickedup = false;
            }
        }

        if (isItPickedup == true)
        {
            allKeysPickedUp = true;
        }
         
    }
    private void OnTriggerStay2D(Collider2D other)
    {
        if (other.CompareTag(player))
        {
            if (allKeysPickedUp == true)
            {
                keysFound.SetActive(true);
                Debug.Log("TEXT POPUP");
                if (Input.GetKeyUp(use))
                {
                    door.SetActive(true);
                    Debug.Log("Reset Keys");
                    RedKey.SetActive(false);
                    BlueKey.SetActive(false);
                    YellowKey.SetActive(false);
                }
            }
        }
    }
    private void OnTriggerEnter2D(Collider2D col)
    {
        if (col.CompareTag(player))
        {
            if (allKeysPickedUp == false)
            {
                getMore.SetActive(true);
            }
            else
            {
                keysFound.SetActive(true);
            }
        }
    }
    private void OnTriggerExit2D(Collider2D col)
    {
        if (col.CompareTag(player))
        {
            getMore.SetActive(false);
            keysFound.SetActive(false);
        }
    }

}
