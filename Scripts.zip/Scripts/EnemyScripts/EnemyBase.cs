﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pathfinding;

public abstract class EnemyBase : MonoBehaviour
{
    /*
    [Header("Death Effects")]
    [Tooltip("The score the player gains when this enemy is killed")]
    public int scoreValue;
    [Tooltip("The items dropped when this enemy dies")]
    public DropStuffOnDeath droppedLoot;
    [Tooltip("The gameobjects spawned when this enemy dies")]
    public List<GameObject> droppedPrefabs;
    [Header("Health Related")]
    [Tooltip("The maximum amount of health this enemy has")]
    public float maxHealth;
    [Tooltip("The rate at which health regenerates(-1 for no regeneration)")]
    public float regenerationRateH;
    [Tooltip("The time between when this enemy was last attacked and when it starts to regenerate health")]
    public float regenerationDelayH;
    [Header("Mana Related")]
    [Tooltip("The maximum amount of mana this enemy has")]
    public float maxMana;
    [Tooltip("The rate at which mana regenerates(-1 for no regeneration)")]
    public float regenerationRateM;
    [Tooltip("The time between when this enemy last used mana and when it starts to regenerate")]
    public float regenerationDelayM;
    [Header("Behavior Options")]
    [Tooltip("The distance the player needs to get to gain the enemy's aggro")]
    public float gainAggro;
    [Tooltip("The distance the player needs to get to lose the enemy's aggro")]
    public float loseAggro;
    [Tooltip("The distance at which the enemy will stop moving towards the player")]
    public float followDistance;
    [Tooltip("The percentage of health at which the enemy will retreat")]
    [Range(0.0f, 100.0f)]
    public float retreatPercentage;
    [Tooltip("The speed at which the enemy moves")]
    public float speed;
    [Tooltip("The basic movement type the enemy will use")]
    public List<Behavior> behaviors;

    private float health;
    private float mana;
    private bool hasAggro;
    private bool isFacingRight;
    private bool isMoving;
    */

    public class action {

        public string actionType;
        public float coolDown;
        public float cdTimer = -1;
        public float time;
        public float range;

        public void callAction()
        {

            cdTimer = Time.time + coolDown;

        }

    }

    public class idle : action
    {

        public idle()
        {

            coolDown = 0;
            time = 0.5f;

        }

    }

    public class charge : action
    {

        public float force;
        
        public charge(float coolDown_, float time_, float force_, float range_)
        {

            actionType = "charge";
            coolDown = coolDown_;
            force = force_;
            time = time_;
            range = range_;

        }

    }

    public class emit : action
    {

        public float angle;
        public int damage;
        public int count;
        public float randomness;
        public float delay;
        public GameObject projectile;
        public float velocity;
        public bool hasGravity;

        public emit(float coolDown_, float time_, float velocity_, float angle_, int damage_, int count_, float randomness_, float delay_, GameObject projectile_, bool hasGravity_, float range_)
        {

            actionType = "emit";
            coolDown = coolDown_;
            time = time_;
            velocity = velocity_;
            angle = angle_;
            damage = damage_;
            count = count_;
            randomness = randomness_;
            delay = delay_;
            projectile = projectile_;
            hasGravity = hasGravity_;
            range = range_;

        }
        
    }

    public class fire : action
    {

        public int damage;
        public int count;
        public float randomness;
        public float delay;
        public GameObject projectile;
        public float velocity;

        public fire(float coolDown_, float time_, float velocity_, int damage_, int count_, float randomness_, float delay_, GameObject projectile_, float range_)
        {

            actionType = "fire";
            coolDown = coolDown_;
            time = time_;
            velocity = velocity_;
            damage = damage_;
            count = count_;
            randomness = randomness_;
            delay = delay_;
            projectile = projectile_;
            range = range_;

        }

    }

    private AIPath path;
    private GameObject player;
    private float targetDistance;
    private int health;
    private bool hasAgro = false;
    private float inAction;
    private bool isFacingRight = true;
    private bool isFollowing;
    public Score score;
    public DropStuffOnDeath loot;
    private List<action> actions;

    void Start()
    {

        player = GameObject.FindGameObjectWithTag("Player");
        StartCoroutine(behaviorTree());

    }

    public void takeDamage(int damage)
    {

        health -= damage;
        if (health <= 0)
        {

            die();

        }

    }

    private void die()
    {

        loot.DropOnDeath();
        Destroy(gameObject);

    }

    private IEnumerator distanceCheck()
    {

        float tmpDist;
        while (true)
        {

            tmpDist = Vector2.Distance(transform.position, player.transform.position);
            if (tmpDist > targetDistance)
            {

                path.enabled = true;

            }
            else if (tmpDist <= targetDistance)
            {

                path.enabled = false;

            }
            yield return new WaitForSeconds(0.5f);

        }

    }

    private IEnumerator behaviorTree()
    {

        while (true)
        {
            if (actions.Count <= 0)
            {

                yield return new WaitForSeconds(0.5f);

            }
            else
            {

                foreach(action a in actions)
                {

                    if (a.cdTimer <= Time.time && a.range >= Vector2.Distance(transform.position, player.transform.position))
                    {

                        switch (a.actionType)
                        {

                            case "charge":



                            break;
                            case "emit":



                            break;
                            case "fire":



                            break;

                        }

                    }

                }

            }

        }

    }

}
