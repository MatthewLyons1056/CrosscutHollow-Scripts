﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Projectile : MonoBehaviour
{

    Rigidbody2D rb;
    private int damage;
    private GameObject sender;
    private PlayerTakeDamage player;

    private void Start()
    {

        player = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerTakeDamage>();

    }

    public void updateStats(bool hasGravity_, int damage_, GameObject sender_, Vector2 velocity_)
    {

        rb = GetComponent<Rigidbody2D>();
        if (hasGravity_)
        {

            rb.gravityScale = 1;

        }
        damage = damage_;
        sender = sender_;
        rb.velocity = velocity_;

    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        
        if (collision.gameObject != sender)
        {

            if (collision.gameObject.CompareTag("Player"))
            {

                player.applyDamge(damage);

            }
            Destroy(gameObject);

        }

    }

    private void Update()
    {

        transform.rotation = Quaternion.Euler(0,0,180 / Mathf.PI * Mathf.Atan2(rb.velocity.y, rb.velocity.x));

    }

}
