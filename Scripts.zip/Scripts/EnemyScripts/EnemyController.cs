﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class EnemyController : MonoBehaviour
{

    [System.Serializable]
    public class attack
    {

        [System.Serializable]
        public class melee
        {

            public float range;

        }
        [System.Serializable]
        public class ranged
        {

            public int projectileCount;
            public float firingDelay;
            public float projectileArc;
            public float projectileRandomness;
            public float velocity;
            public float gravityScale;
            public GameObject projectile;

        }
        [System.Serializable]
        public class emit
        {

            public int projectileCount;
            public float firingDelay;
            public float projectileRandomness;
            public float velocity;
            public float angle;
            public GameObject spawnedObject;

        }
        [System.Serializable]
        public class jump
        {

            public bool isTowardsPlayer;
            public float verticalForce;
            public float horizontalForce;

        }
        [System.Serializable]
        public class charge
        {

            public float chargeForce;

        }

        public enum attackType { Melee, Ranged, Emit, Jump, Charge};
        public float cooldown;
        public float timeCost;
        public float delay;
        public float damage;
        public float manaCost;
        public float maxRange;
        public float minRange;
        public attackType typeOfAttack;
        public melee ifMelee;
        public ranged ifRanged;
        public emit ifEmit;
        public jump ifJump;
        public charge ifCharge;


    }

    [Header("Death Effects")]
    [Tooltip("The score the player gains when this enemy is killed")]
    public int scoreValue;
    [Tooltip("The items dropped when this enemy dies")]
    public DropStuffOnDeath droppedLoot;
    [Tooltip("The gameobjects spawned when this enemy dies")]
    public List<GameObject> droppedPrefabs;
    [Header("Health Related")]
    [Tooltip("The maximum amount of health this enemy has")]
    public float maxHealth;
    [Tooltip("The rate at which health regenerates(-1 for no regeneration)")]
    public float regenerationRateH;
    [Tooltip("The time between when this enemy was last attacked and when it starts to regenerate health")]
    public float regenerationDelayH;
    [Header("Mana Related")]
    [Tooltip("The maximum amount of mana this enemy has")]
    public float maxMana;
    [Tooltip("The rate at which mana regenerates(-1 for no regeneration)")]
    public float regenerationRateM;
    [Tooltip("The time between when this enemy last used mana and when it starts to regenerate")]
    public float regenerationDelayM;
    [Header("Behavior Options")]
    [Tooltip("The distance the player needs to get to gain the enemy's aggro")]
    public float gainAggro;
    [Tooltip("The distance the player needs to get to lose the enemy's aggro")]
    public float loseAggro;
    [Tooltip("The distance at which the enemy will stop moving towards the player")]
    public float followDistance;
    [Tooltip("The percentage of health at which the enemy will retreat")]
    [Range(0.0f, 100.0f)]
    public float retreatPercentage;
    [Tooltip("The speed at which the enemy moves")]
    public float speed;
    [Tooltip("The basic movement type the enemy will use")]
    public aiType typeOfAI;
    [Tooltip("The list of abilities the enemy has(It will attempt to perform the actions in the order of the list, and will perform the first one it is able to)")]
    public List<attack> abilities;

    private float health;
    private float mana;
    private bool hasAggro;
    private bool isFacingRight;
    private bool isMoving;

    public enum aiType { bat, walking };

    void Start()
    {

    }

    void Update()
    {

    }


}




