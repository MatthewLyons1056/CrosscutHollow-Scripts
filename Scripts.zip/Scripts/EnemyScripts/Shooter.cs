﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pathfinding;

public class Shooter : MonoBehaviour
{

    [Range(-1, 360)]
    public int angle = -1;
    public float period = 1.0f;
    public GameObject projectile;
    public float range = 10;
    public float speed = 1;
    public bool hasGravity = false;
    public float randomness = 0;
    private GameObject player;
    private AIPath aiPath;
    private float toRads = Mathf.PI / 180;

    void Start()
    {

        player = GameObject.FindGameObjectWithTag("Player");
        StartCoroutine(firingCheck());
        aiPath = GetComponent<AIPath>();

    }

    private IEnumerator firingCheck()
    {

        while (true)
        {

            yield return new WaitForSeconds(period);
            if (Vector2.Distance(player.transform.position, transform.position) <= range)
            {

                fire();
                Debug.Log("enemy fire");

            }


        }

    }

    private void fire()
    {

        Vector2 velocity = new Vector2();
        if (angle == -1)
        {

            velocity = player.transform.position - transform.position;
            velocity = velocity.normalized * speed;

        }
        else
        {

            float tmpAngle = angle;
            if (aiPath.desiredVelocity.x < 0f)
            {

                tmpAngle = 180 - angle;

            }
            velocity.x = Mathf.Cos(toRads * tmpAngle);
            velocity.y = Mathf.Sin(toRads * tmpAngle);
            velocity = velocity.normalized * speed;

        }
        GameObject tmpProjectile = Instantiate(projectile, transform.position, Quaternion.identity);
        tmpProjectile.GetComponent<Projectile>().updateStats(hasGravity, 1, this.gameObject, velocity);

    }

}
