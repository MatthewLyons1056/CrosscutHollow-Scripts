﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Behavior : MonoBehaviour
{

    [System.Serializable]
    public class attack
    {

        [System.Serializable]
        public class melee
        {

            public float range;

        }
        [System.Serializable]
        public class ranged
        {

            public int projectileCount;
            public float firingDelay;
            public float projectileArc;
            public float projectileRandomness;
            public float velocity;
            public float gravityScale;
            public GameObject projectile;

        }
        [System.Serializable]
        public class emit
        {

            public int projectileCount;
            public float firingDelay;
            public float projectileRandomness;
            public float velocity;
            public float angle;
            public GameObject spawnedObject;

        }
        [System.Serializable]
        public class jump
        {

            public bool isTowardsPlayer;
            public float verticalForce;
            public float horizontalForce;

        }
        [System.Serializable]
        public class charge
        {

            public float chargeForce;

        }

        public enum attackType { Melee, Ranged, Emit, Jump, Charge };
        public float cooldown;
        public float timeCost;
        public float delay;
        public float damage;
        public float manaCost;
        public float maxRange;
        public float minRange;
        public attackType typeOfAttack;
        public melee ifMelee;
        public ranged ifRanged;
        public emit ifEmit;
        public jump ifJump;
        public charge ifCharge;


    }

}
