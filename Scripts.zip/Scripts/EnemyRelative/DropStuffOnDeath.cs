﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DropStuffOnDeath : MonoBehaviour
{
    public GameObject enemy;
    public GameObject[] loot;
    public int lootNumber;
    public int lootPicker;


    // Start is called before the first frame update
    void Start()
    {
        lootNumber = loot.Length;

        lootPicker = Random.Range(0, lootNumber);

    }

    // Update is called once per frame
    void Update()
    {

    }

    public void DropOnDeath()
    {
        Debug.Log("SpawnSomething");
        Instantiate(loot[lootPicker], enemy.transform.position, Quaternion.identity);

    }


}
