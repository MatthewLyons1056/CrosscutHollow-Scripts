﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TheBoneScript : MonoBehaviour
{

    public AudioClip clip;

    void OnTriggerEnter2D(Collider2D col)
    {
        if (col.gameObject.CompareTag("Projectile"))
        {

            AudioSource.PlayClipAtPoint(clip, new Vector3(0, 0, 0));

            //Debug.Log("bOnE nOiSEs");
        }


        
    }
}
