﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TextDisplay : MonoBehaviour


{
    public Text text;

    void Awake()
    {
        text = GameObject.Find("DisplayText").GetComponent<Text>();
    }
    void OnTriggerEnter2D(Collider2D collisionInfo)
    {
        if (collisionInfo.gameObject.CompareTag("Player"))
        {
            //Display Text
            Debug.Log("Display text");
        }
    }
}
