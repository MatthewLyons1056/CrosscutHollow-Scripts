﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HintCollision : MonoBehaviour
{
    //In game UI pop ups
    //public GameObject testText;

    //For the Collection of badges
    [Tooltip("Displays the hint inside the journal.Objectives")]
    public GameObject hintGFX;
    [Tooltip("Displays the hint for the canvas, under canvas.HintDisplay")]
    public GameObject hintText;

    //Controls IEnumerator
    private float secUI = 2f;

    

    //Gets rid of the badge in game and puts it on the pause menu UI.
    private void OnTriggerEnter2D(Collider2D col)
    {
        if (col.gameObject.tag == "Player")
        {

            Debug.Log("Hint Recieved");
            

            //Sets UI button in pause menu active
            hintGFX.SetActive(true);

            //Shows the badge pickup text
            hintText.SetActive(true);
            Destroy(gameObject.GetComponent<BoxCollider2D>());
        }
    }

    private void OnTriggerExit2D(Collider2D col)
    {
        if (col.gameObject.tag == "Player")
        {
            StartCoroutine(TextSpawn());
            IEnumerator TextSpawn()
            {
                //Shows the text for a certain amount of time.
                yield return new WaitForSeconds(secUI);
                hintText.SetActive(false);
            }
        }
    }
}
