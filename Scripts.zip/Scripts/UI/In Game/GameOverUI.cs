﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class GameOverUI : MonoBehaviour
{

    private CheckpointManager player;
    private GameOver gameOverScript;

    private void Start()
    {

        gameOverScript = GameObject.FindGameObjectWithTag("Player").GetComponent<GameOver>();
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<CheckpointManager>();

    }

    public void Restart()
    {

        player.gameObject.transform.position = player.getCheckpoint().respawnPoint + player.getCheckpoint().gameObject.transform.position;
        gameOverScript.HidePanel();

    }

    public void MainMenu()
    {
        SceneManager.LoadScene(0);
    }
    
}
