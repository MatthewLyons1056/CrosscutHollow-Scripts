﻿using UnityEngine;

public class OnTriggerEnter : MonoBehaviour
{


    void OnCollisionEnter2D()    
    {
        Debug.Log("hit");
    }
}
